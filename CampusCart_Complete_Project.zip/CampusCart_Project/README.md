# CampusCart — runnable starter project

A Flask + SQLite web application prototype based on the CampusCart SRS supplied with the project.

## Included modules
- Student registration and login (passwords hashed)
- Optional institutional email-domain restriction
- Student profiles (name and campus location field in the data model)
- Create, browse, search and filter item listings
- Listing status: Available / Reserved / Sold
- Buyer offers and seller accept/decline responses
- Basic meetup time and location fields on accepted offers
- Seller reviews, listing reports and a basic admin dashboard
- Responsive HTML/CSS interface

## Run locally

Requires Python 3.10+.

```bash
# 1. Create and activate a virtual environment
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS / Linux:
source .venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Optional: configure institutional email domain
# Copy .env.example to .env and set COLLEGE_EMAIL_DOMAIN.
# Environment variables can also be set directly in your shell.

# 4. Start the app
python run.py
```

Open http://127.0.0.1:5000

The SQLite database is created automatically in `instance/campuscart.db`.

## Create an admin account

Register a normal user first. Then open a Python shell from the project directory:

```bash
python
>>> from app import create_app, db
>>> from app.models import User
>>> app = create_app()
>>> with app.app_context():
...     user = User.query.filter_by(email="your-email@yourcollege.edu").first()
...     user.is_admin = True
...     db.session.commit()
```

Log out and log in again. The Admin link will appear.

## Important implementation notes

This is an educational MVP / starter implementation, not a production-ready marketplace. The SRS lists several items that require further implementation or external services:
- Email verification and Google OAuth are not wired to a provider.
- Live WebSocket chat and email/SMS notifications are not implemented; the current version provides offer workflows and basic in-app flash feedback.
- The listing form currently accepts one image URL rather than uploading up to five images to object storage.
- Meetup details are basic fields on offer acceptance; robust two-party confirmation, cancellation reasons and transaction completion workflow need further work.
- Reviews are a basic prototype and need stronger transaction eligibility checks and duplicate-review prevention.
- Admin verification is a simple toggle, not a document/college-ID verification integration.
- No payment gateway is included. Buyer and seller settle payment directly at the meetup, as specified in the SRS.
- Add CSRF protection, rate limiting, secure production secrets, HTTPS deployment, audit logs, automated tests, accessibility testing and privacy/legal review before real deployment.

## Suggested next steps
1. Confirm the college email domain and final technology stack.
2. Add email verification and Google OAuth.
3. Add secure image uploads and multiple images per listing.
4. Implement real-time messaging and notifications.
5. Complete transaction handover confirmation and review eligibility.
6. Add automated tests and deploy to a cloud host.

## Project structure

```text
CampusCart_Project/
├── app/
│   ├── __init__.py
│   ├── models.py
│   ├── routes.py
│   ├── templates/
│   └── static/style.css
├── instance/
├── requirements.txt
├── run.py
├── .env.example
└── README.md
```
