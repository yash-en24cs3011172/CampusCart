from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import or_
from . import db
from .models import User, Listing, Offer, Review, Report

bp = Blueprint("main", __name__)

CATEGORIES = ["Books & Stationery", "Electronics & Gadgets", "Furniture & Room Essentials",
              "Cycles & Vehicles", "Others"]
CONDITIONS = ["New", "Like New", "Good", "Fair"]

def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Please log in to continue.", "warning")
            return redirect(url_for("main.login"))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if not current_user().is_admin:
            flash("Admin access required.", "danger")
            return redirect(url_for("main.index"))
        return fn(*args, **kwargs)
    return wrapper

@bp.context_processor
def inject_globals():
    return {"current_user": current_user(), "categories": CATEGORIES}

@bp.route("/")
def index():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "")
    condition = request.args.get("condition", "")
    min_price = request.args.get("min_price", "")
    max_price = request.args.get("max_price", "")
    query = Listing.query.filter_by(status="Available")
    if q:
        query = query.filter(or_(Listing.title.ilike(f"%{q}%"),
                                 Listing.description.ilike(f"%{q}%")))
    if category:
        query = query.filter_by(category=category)
    if condition:
        query = query.filter_by(condition=condition)
    if min_price:
        try: query = query.filter(Listing.price >= float(min_price))
        except ValueError: pass
    if max_price:
        try: query = query.filter(Listing.price <= float(max_price))
        except ValueError: pass
    listings = query.order_by(Listing.created_at.desc()).all()
    return render_template("index.html", listings=listings, q=q, category=category,
                           condition=condition, min_price=min_price, max_price=max_price,
                           conditions=CONDITIONS)

@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        domain = current_app.config.get("COLLEGE_EMAIL_DOMAIN", "").strip().lower()
        if not name or not email or len(password) < 8:
            flash("Enter your name, email and a password of at least 8 characters.", "danger")
        elif domain and not email.endswith("@" + domain):
            flash(f"Use your institutional email ending in @{domain}.", "danger")
        elif User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "danger")
        else:
            user = User(name=name, email=email, password_hash=generate_password_hash(password))
            db.session.add(user); db.session.commit()
            session["user_id"] = user.id
            flash("Account created. Configure institutional email verification before production.", "success")
            return redirect(url_for("main.index"))
    return render_template("auth.html", mode="Register")

@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            session["user_id"] = user.id
            flash("Welcome back!", "success")
            return redirect(url_for("main.index"))
        flash("Invalid email or password.", "danger")
    return render_template("auth.html", mode="Login")

@bp.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.index"))

@bp.route("/listing/new", methods=["GET", "POST"])
@login_required
def new_listing():
    if request.method == "POST":
        try: price = float(request.form.get("price", "0"))
        except ValueError: price = -1
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        category = request.form.get("category", "")
        condition = request.form.get("condition", "")
        if not title or not description or price < 0 or category not in CATEGORIES or condition not in CONDITIONS:
            flash("Please complete all fields with a valid price.", "danger")
        else:
            item = Listing(title=title, description=description, category=category,
                           condition=condition, price=price,
                           location=request.form.get("location", "").strip(),
                           image_url=request.form.get("image_url", "").strip(),
                           seller_id=current_user().id)
            db.session.add(item); db.session.commit()
            flash("Your listing is now live.", "success")
            return redirect(url_for("main.listing_detail", listing_id=item.id))
    return render_template("listing_form.html", conditions=CONDITIONS)

@bp.route("/listing/<int:listing_id>")
def listing_detail(listing_id):
    item = Listing.query.get_or_404(listing_id)
    reviews = Review.query.filter_by(seller_id=item.seller_id).order_by(Review.created_at.desc()).limit(5).all()
    return render_template("listing_detail.html", item=item, reviews=reviews)

@bp.route("/listing/<int:listing_id>/status", methods=["POST"])
@login_required
def update_status(listing_id):
    item = Listing.query.get_or_404(listing_id)
    if item.seller_id != current_user().id and not current_user().is_admin:
        flash("You can only update your own listings.", "danger")
    else:
        status = request.form.get("status")
        if status in ["Available", "Reserved", "Sold"]:
            item.status = status; db.session.commit()
            flash("Listing status updated.", "success")
    return redirect(url_for("main.listing_detail", listing_id=listing_id))

@bp.route("/listing/<int:listing_id>/offer", methods=["POST"])
@login_required
def make_offer(listing_id):
    item = Listing.query.get_or_404(listing_id)
    if item.seller_id == current_user().id:
        flash("You cannot make an offer on your own listing.", "warning")
        return redirect(url_for("main.listing_detail", listing_id=listing_id))
    try: amount = float(request.form.get("amount", "0"))
    except ValueError: amount = 0
    if amount <= 0:
        flash("Enter a valid offer amount.", "danger")
    else:
        offer = Offer(listing_id=item.id, buyer_id=current_user().id, amount=amount,
                      message=request.form.get("message", "").strip())
        db.session.add(offer); db.session.commit()
        flash("Offer sent to the seller.", "success")
    return redirect(url_for("main.listing_detail", listing_id=listing_id))

@bp.route("/offers")
@login_required
def offers():
    user = current_user()
    incoming = Offer.query.join(Listing).filter(Listing.seller_id == user.id).order_by(Offer.created_at.desc()).all()
    outgoing = Offer.query.filter_by(buyer_id=user.id).order_by(Offer.created_at.desc()).all()
    return render_template("offers.html", incoming=incoming, outgoing=outgoing)

@bp.route("/offer/<int:offer_id>/respond", methods=["POST"])
@login_required
def respond_offer(offer_id):
    offer = Offer.query.get_or_404(offer_id)
    if offer.listing.seller_id != current_user().id:
        flash("Only the seller can respond to this offer.", "danger")
    else:
        action = request.form.get("action")
        if action in ["Accepted", "Declined", "Countered"]:
            offer.status = action
            offer.meetup_time = request.form.get("meetup_time", "").strip()
            offer.meetup_location = request.form.get("meetup_location", "").strip()
            db.session.commit()
            if action == "Accepted":
                offer.listing.status = "Reserved"
                db.session.commit()
            flash(f"Offer {action.lower()}.", "success")
    return redirect(url_for("main.offers"))

@bp.route("/review/<int:listing_id>", methods=["POST"])
@login_required
def review_seller(listing_id):
    item = Listing.query.get_or_404(listing_id)
    if item.status != "Sold" or item.seller_id == current_user().id:
        flash("Reviews are available to buyers after a listing is marked Sold.", "warning")
    else:
        try: rating = int(request.form.get("rating", "5"))
        except ValueError: rating = 0
        if 1 <= rating <= 5:
            db.session.add(Review(listing_id=item.id, reviewer_id=current_user().id,
                                  seller_id=item.seller_id, rating=rating,
                                  comment=request.form.get("comment", "").strip()))
            db.session.commit()
            flash("Thank you for your review.", "success")
    return redirect(url_for("main.listing_detail", listing_id=listing_id))

@bp.route("/report/<int:listing_id>", methods=["POST"])
@login_required
def report_listing(listing_id):
    item = Listing.query.get_or_404(listing_id)
    reason = request.form.get("reason", "").strip()
    if reason:
        db.session.add(Report(listing_id=item.id, reporter_id=current_user().id, reason=reason))
        db.session.commit()
        flash("Report submitted for admin review.", "success")
    return redirect(url_for("main.listing_detail", listing_id=listing_id))

@bp.route("/admin")
@admin_required
def admin():
    return render_template("admin.html",
        users=User.query.order_by(User.created_at.desc()).all(),
        listings=Listing.query.order_by(Listing.created_at.desc()).all(),
        reports=Report.query.order_by(Report.created_at.desc()).all(),
        total_offers=Offer.query.count())

@bp.route("/admin/user/<int:user_id>/toggle", methods=["POST"])
@admin_required
def toggle_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id != current_user().id:
        user.is_verified = not user.is_verified
        db.session.commit()
        flash("Verification status changed.", "success")
    return redirect(url_for("main.admin"))

@bp.route("/admin/report/<int:report_id>/close", methods=["POST"])
@admin_required
def close_report(report_id):
    report = Report.query.get_or_404(report_id)
    report.status = "Closed"; db.session.commit()
    return redirect(url_for("main.admin"))

@bp.route("/health")
def health():
    return {"status": "ok", "app": "CampusCart"}
